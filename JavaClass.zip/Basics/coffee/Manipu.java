// Write a method that prints all the numbers from 1 to 255.
public class Manipu {

/* OOP: Object Orientated Programming
In OOP there exists instances and classes. A class defines how an instance is made
and what it contains. The use of 'this' allows us to use a specific instance member
*/
    //public - accessor (public, protected, private)
    //static - Refers to when we are talking about the class itself
    //void refers to the return type(void, int, String, bool)
    //main refers to the entry point, when running the program
    //(String[] args) refers to the function parameters as given to the file

    // DRY - Don't Repeat yourself


    public static void main(String[] args){
        Person person1 = new Person();
        Person person2 = new Person();
        person2.name = "Mimi";
        person2.age = 30;
        person2.sex = "Female";

        for (int i=0; i < args.length; i++) {
            System.out.println(args[i]);
        }
        // person2.printNumbers(1000000);

        // Numb.staticPrintNumbers();
    }
}

//Write a method that takes an array and returns the number of values in that array whose value is greater 
//than a given value y. For example, if array = [1, 3, 5, 7] and y = 3, after your method is run it will print
//2 (since there are two values in the array that are greater than 3).

// public class Manipu{
//     public static void main(Strings[] args){
//         int arr[] = {1, 3, 5, 7};
//         for (i > )
//     }

// }