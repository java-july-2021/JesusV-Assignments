public class Person{
    public static String race = "Human";
    public String name = "Jesus";
    public int age = 30;
    public String sex = "Male";
    public int[] Scores = { 99};
    
    public void details() {
        System.out.println(this.name);
        System.out.println(this.age);
        System.out.println(this.sex);
    }

    public void printNumbers(int magicNumber){
        for(int i=0; i <= magicNumber; i++){
            System.out.println(i);
        } 
    }

    public void canFly(){
        System.out.println("I can fly");
    }
    public static void main(String[] args){
        System.out.println();
    }
}