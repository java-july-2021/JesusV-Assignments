//Write a method that creates an ArrayList 'y' that contains all the odd numbers between 1 to 255. 
//When the method is done, 'y' should have the value of [1, 3, 5, 7, ... 255].
//Needs Work

  public class arrayList {
      public static void main(String[] args){
          arr [i < 255];
          for (i = 0; i <= 255; i++){
              if (i % 2 == 1){
                  System.out.println(arr[i]);
                }
        }
       
    }
}

