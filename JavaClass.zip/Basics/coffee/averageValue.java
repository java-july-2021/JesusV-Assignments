package coffee;

// Write a method that takes an array, and prints the AVERAGE of the values in the array. 
// For example for an array [2, 10, 3], your method should print an average of 5. Again, make sure you come up 
// with a simple base case and write instructions to solve that base case first, then test your instructions for 
// other complicated cases.
// Needs work

 public class averageValue {
     public static void main(String[] args){
         int arr[] = {2, 10, 3};
         int i, sum, avg;
         sum = 0;
         for (i = 0; i < arr.length; i++){
             sum += arr[i];
         }

         avg = sum / arr.length;
         System.out.println(avg);
     }
}