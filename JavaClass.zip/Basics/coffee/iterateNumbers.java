//Given an array X, say [1,3,5,7,9,13], write a method that would iterate through each member of the array and 
//print each value on the screen. Being able to loop through each member of the array is extremely important. 

 public class iterateNumbers {
     public static void main(String[] args){
         int arr[] = {1, 3, 5, 7, 9, 13};
         for (int i = 0; i < arr.length; i++) {
             System.out.println(arr[i]);
         }
     }
 }