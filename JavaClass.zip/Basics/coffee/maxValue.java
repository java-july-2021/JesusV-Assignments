package coffee;

// Write a method (sets of instructions) that takes any array and prints the maximum value in the array. 
// Your method should also work with a given array that has all negative numbers (e.g. [-3, -5, -7]), or 
// even a mix of positive numbers, negative numbers and zero.
//Needs work

 public class maxValue {
     public static void main(String[] args){
         int arr[] = {-3, -5, -7, -1, 0};

         int largest = largeArray[0]; 

         for (int i = 0; i < arr.length; i++){
             if (largeArray[i] > largest) largest = largeArray[i];

        
         System.out.println(largest);
         }
     }
 }

