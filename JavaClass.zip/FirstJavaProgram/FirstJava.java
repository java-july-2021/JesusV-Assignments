public class FirstJava {
    public  static void main(String[] args){
        System.out.printIn("My name is Coding Dojo
        I am 100 years old
        My hometown is Burbank, CA
        ");
    }
}