public class StansDonuts {

    public static void songTracks(String[] args){
        HashMap<String, String> songArtist = new HashMap<String, String>();
        songArtist.put("Stan", "Eminem");
        songArtist.put("Still DRE", "Dr. Dre");

    }

    public static void Main(String[] args){

    }
}