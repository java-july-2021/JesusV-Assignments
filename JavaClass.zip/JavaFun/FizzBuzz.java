public class FizzBuzz {
 
    public String fizzBuzz(int number){
        if(number / 3){
            return String "Fizz";
        }
        el
    }
}