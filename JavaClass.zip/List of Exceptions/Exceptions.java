public class Exceptions{
    
    public static void main(String[] args){

    }

}