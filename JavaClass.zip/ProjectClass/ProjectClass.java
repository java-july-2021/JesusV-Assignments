public class ProjectClass{
    public static void getName(String word){
        String = "Jesus";
    }
    public static void main(String[] args){
        System.out.println(getName());
    }
}