public class Puzzling {

    // public static void carList(String[] args){
    //     String[] cars = {"Kia", "Ford", "Honda", "Chevy", "Nissan"};
    // }

    // public static void carArray(String word){
    //     for (i=0, i < word.length(), i++);

    // }

    public static void main(String[] args){
        
    }
}