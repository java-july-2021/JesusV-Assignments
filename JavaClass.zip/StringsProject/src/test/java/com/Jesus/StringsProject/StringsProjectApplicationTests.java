package com.Jesus.StringsProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;

@SpringBootTest
class StringsProjectApplicationTests {

	@Test
	void contextLoads() {
	}
	
}
