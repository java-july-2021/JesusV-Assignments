public class Gorilla {
    public static void throwSomething(String word){

    }
    public static void eatBananas(String word){

    }
    public static void climb(String word){
        
    }
    public static void main(String[] args){

    }
}
