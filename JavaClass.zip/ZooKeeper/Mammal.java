public class Mammal {
    public String energyLevel;
}

public displayEnergy (String energyLevel){
    this.energyLevel = energyLevel;
}
