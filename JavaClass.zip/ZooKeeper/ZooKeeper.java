public class ZooKeeper {


    public static void main(String[] args) {
        System.out.println(energyLevel());
    }
}