package com.Jesus.displaydate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import java.util.Date;

@SpringBootApplication
public class Displaydate1Application {

	public static void main(String[] args) {
		SpringApplication.run(Displaydate1Application.class, args);
	}

}
