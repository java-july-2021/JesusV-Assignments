package com.Jesus.language.controllers;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import com.Jesus.language.services.*;
import como.Jesus.language.model.language;

@RestController
public class languageControllers {
	@Autowired
	private languageService lService;
	
	@GetMapping("/")
	public String index() {
		return "index.jsp";
	}

	@GetMapping("/languages")
	public List<language> allLanguages(){
		return lService.getAllCreators();
	}
	
	@GetMapping("/languages/{id}")
	public language getCreator(@PathVariable("id") Long id) {
		return this.lService.getSingleCreator(id);
	}

}
