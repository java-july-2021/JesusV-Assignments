package com.Jesus.language.respository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import como.Jesus.language.model.language;

@Repository
public interface languageRepository extends CrudRepository<language, Long> {
	List<language> findAll();

}
