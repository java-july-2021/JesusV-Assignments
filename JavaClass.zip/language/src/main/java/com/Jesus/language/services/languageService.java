package com.Jesus.language.services;

import java.util.List;
import org.springframework.stereotype.Service;
import com.Jesus.language.respository.*;
import como.Jesus.language.model.language;

@Service
public class languageService {
	private languageRepository lRepo;
	
	public languageService(languageRepository repo) {
		this.lRepo = repo;
	}
	
	public List<language> getAllCreators(){
		return this.lRepo.findAll();
	}
	
	public language getSingleCreator(Long id) {
		return this.lRepo.findById(id).orElse(null);
	}
	
	public language createCreator(language newCreator) {
		return this.lRepo.save(newCreator);
	}
		
	public language updateCreator(language updatedCreator) {
		return this.lRepo.save(updatedCreator);
	}
	
	public void deleteCreator(Long id) {
		this.lRepo.deleteById(id);
	}

}
