package com.Jesus.lookify.controllers;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.Jesus.lookify.services.*;
import com.Jesus.lookify.model.*;

@Controller
public class lookifyControllers {
	@RequestMapping("/")
	public String index() {
	return "index.jsp";
	}
	
	@RequestMapping("/dashboard")
	public String search() {
	return "dashboard.jsp";
	}

}
