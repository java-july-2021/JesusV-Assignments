package com.Jesus.routingproject1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Routingproject1Application {

	public static void main(String[] args) {
		SpringApplication.run(Routingproject1Application.class, args);
	}

}
