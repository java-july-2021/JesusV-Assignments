package com.Jesus.routingproject1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Routingproject1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
