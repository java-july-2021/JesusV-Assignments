package com.Jesus.theshow.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class theShow {
	@RequestMapping("/")
	public String index(){
		return "index.jsp";
	}
	
	@RequestMapping("/books")
	public String bookList(){
		return "books.jsp";
	}
	
	@RequestMapping("/books/1")
	public String show(){
		return "new.jsp";
	}

}
