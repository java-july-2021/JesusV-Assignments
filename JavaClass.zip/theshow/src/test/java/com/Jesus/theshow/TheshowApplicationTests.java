package com.Jesus.theshow;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TheshowApplicationTests {

	@Test
	void contextLoads() {
	}

}
