package com.Jesus.updateanddelete;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UpdateanddeleteApplicationTests {

	@Test
	void contextLoads() {
	}

}
